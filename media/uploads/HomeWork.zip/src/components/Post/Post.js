import React from 'react'

function Post(props) {
  return (
    <div>
        { props.content }
    </div>
  )
}

export default Post 
